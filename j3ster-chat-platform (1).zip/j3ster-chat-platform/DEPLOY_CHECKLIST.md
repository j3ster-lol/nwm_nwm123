# Before public launch

- [ ] Provision production PostgreSQL and set environment variables.
- [ ] Apply reviewed Prisma migrations.
- [ ] Create owner once via secure terminal.
- [ ] Confirm build succeeds in hosting CI.
- [ ] Add shared-store rate limiting and email verification/recovery.
- [ ] Finish and test every feature listed as unfinished in README.
- [ ] Configure privacy policy, terms, backups, logs, alerting and abuse response.
- [ ] Run integration, accessibility and security tests.
- [ ] Only then invite real users.

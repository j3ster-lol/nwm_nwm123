# J3STER // NETWORK — communication platform starter

This repository is a working **foundation**, not a finished Discord replacement. It includes a Next.js app, PostgreSQL/Prisma schema, password login/registration, signed HTTP-only sessions, server creation, membership checks, text messages with polling, owner bootstrap, basic admin gate, security headers and input-validation tests. It intentionally identifies unfinished functions below rather than pretending they work.

## Requirements
- Node.js 20.9+
- PostgreSQL database (managed provider recommended)
- A hosting provider that supports Next.js server routes and environment variables (e.g. Vercel)
- A generated `SESSION_SECRET` with at least 32 characters

## Local setup
1. Create a PostgreSQL database.
2. Copy `.env.example` to `.env` and fill `DATABASE_URL`, `APP_URL`, and a long random `SESSION_SECRET`.
3. Install dependencies: `npm install`
4. Generate Prisma client: `npm run db:generate`
5. Create/apply the first schema migration in development: `npx prisma migrate dev --name init`
6. Start the app: `npm run dev`
7. Create the owner only once, after migration. Set `OWNER_EMAIL`, `OWNER_USERNAME`, and a unique `OWNER_INITIAL_PASSWORD` of at least 16 characters in the server environment, then run `npm run owner:init`. Remove the initial password variable immediately afterwards. Do not expose this command as a public HTTP endpoint.

For a production database, use `npx prisma migrate deploy` (or `npm run db:migrate`) after creating and reviewing a migration in development. Do not run `migrate dev` in production.

## Deploy outline
1. Push this project to a private Git repository.
2. Import it into a Next.js-compatible hosting provider.
3. Provision managed PostgreSQL and set `DATABASE_URL`, `APP_URL`, and `SESSION_SECRET` in hosting environment settings.
4. Deploy. Apply database migrations as a controlled release step (`npm run db:migrate`).
5. Run owner bootstrap once in a secure terminal with the owner environment variables. Never put owner credentials in the repository or browser.
6. Test registration, login, server creation, channel access and message posting against the deployed database before inviting users.

**This workspace has not been connected to your hosting or database account, and no external deployment has been performed.** I cannot honestly say the app has been production-built or published without those services being configured.

## Implemented in this starter
- Registration and login using bcrypt password hashes
- Signed seven-day session cookie (`HttpOnly`, `SameSite=Lax`, `Secure` in production)
- User, server, membership, category, channel, message, reaction, friendship, badge, report, audit and rate-limit schema
- Create/list servers and create a default text channel
- Read and post text messages; membership is checked on the server
- Polling refresh for new messages (not WebSocket realtime)
- One-time owner bootstrap script; registration cannot assign OWNER
- Server-side admin overview endpoint with role gate
- Input schemas and basic security headers

## Not yet implemented — do not advertise as complete
- Email verification, password recovery, session revocation/device management, MFA and robust login rate limiting
- WebSocket/push realtime, DMs, friend workflows, invite-join endpoint, role/permission editor and per-channel ACLs
- Message edits/deletes, attachments and safe object storage, reaction API, notifications
- Profile editing, avatar/banner upload, custom badges/decorations and badge assignment UI
- Owner dashboard actions for users, servers, reports, bans, timed restrictions and audit-log viewer
- Granular administrator permissions, automated spam detection and anti-abuse controls
- Privacy/data export/deletion flows and account settings
- Full automated integration/E2E/security tests
- Production build verification and live deployment

## Security notes
- Never commit `.env` or any secret.
- Owner bootstrap intentionally fails if an owner already exists. If the owner account is lost, use a documented, authenticated server-side recovery process rather than opening a public bootstrap endpoint.
- Use HTTPS, managed secrets, database backups, dependency updates and centralized error monitoring in production.
- Before public launch, add rate limiting backed by a shared store, email verification and recovery, CSRF/origin checks for state-changing requests, upload scanning/storage policy, privacy terms and an independent security review.

import "dotenv/config";
import bcrypt from "bcryptjs";
import { db } from "../src/lib/db";
async function main() {
  const email = process.env.OWNER_EMAIL?.toLowerCase();
  const username = process.env.OWNER_USERNAME;
  const password = process.env.OWNER_INITIAL_PASSWORD;
  if (!email || !username || !password || password.length < 16 || password === "CHANGE_THIS_TO_A_LONG_UNIQUE_PASSWORD") {
    throw new Error("Set OWNER_EMAIL, OWNER_USERNAME and a unique OWNER_INITIAL_PASSWORD (at least 16 characters) in the environment before running this script.");
  }
  const existingOwner = await db.user.findFirst({ where: { globalRole: "OWNER" }, select: { id: true } });
  if (existingOwner) throw new Error("An OWNER already exists. Bootstrap is one-time only.");
  const collision = await db.user.findFirst({ where: { OR: [{ email }, { username }] }, select: { id: true } });
  if (collision) throw new Error("The owner email or username is already in use. Resolve the collision before bootstrap.");
  const user = await db.user.create({ data: { email, username, passwordHash: await bcrypt.hash(password, 12), globalRole: "OWNER" }, select: { id: true, email: true, username: true } });
  await db.auditLog.create({ data: { actorId: user.id, action: "OWNER_BOOTSTRAP", targetType: "User", targetId: user.id } });
  console.log(`Owner created: ${user.username} (${user.email}). Remove OWNER_INITIAL_PASSWORD from environment now.`);
}
main().finally(async () => db.$disconnect());
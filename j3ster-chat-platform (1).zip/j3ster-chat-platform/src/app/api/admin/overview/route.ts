import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { currentUser } from "@/lib/auth";
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  if (user.globalRole !== "OWNER" && user.globalRole !== "ADMIN") return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  const [users, servers, messages, reports] = await Promise.all([
    db.user.count(), db.server.count(), db.message.count({ where: { deletedAt: null } }), db.report.count({ where: { status: "OPEN" } })
  ]);
  return NextResponse.json({ users, servers, messages, openReports: reports });
}
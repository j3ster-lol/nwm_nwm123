import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (typeof body.email !== "string" || typeof body.password !== "string" || body.password.length > 128)
      return NextResponse.json({ error: "Neplatné přihlašovací údaje." }, { status: 400 });
    const user = await db.user.findUnique({ where: { email: body.email.toLowerCase() } });
    if (!user || user.disabledAt || !(await bcrypt.compare(body.password, user.passwordHash)))
      return NextResponse.json({ error: "Neplatný e-mail nebo heslo." }, { status: 401 });
    await createSession(user.id);
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "Přihlášení momentálně není dostupné." }, { status: 500 }); }
}
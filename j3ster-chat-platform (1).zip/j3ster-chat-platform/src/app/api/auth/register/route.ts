import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { registerSchema } from "@/lib/validation";
export async function POST(req: Request) {
  try {
    const parsed = registerSchema.safeParse(await req.json());
    if (!parsed.success) return NextResponse.json({ error: "Zkontroluj e-mail, uživatelské jméno a heslo (min. 12 znaků)." }, { status: 400 });
    const { email, username, password } = parsed.data;
    const exists = await db.user.findFirst({ where: { OR: [{ email: email.toLowerCase() }, { username }] }, select: { id: true } });
    if (exists) return NextResponse.json({ error: "E-mail nebo uživatelské jméno už existuje." }, { status: 409 });
    const user = await db.user.create({ data: { email: email.toLowerCase(), username, passwordHash: await bcrypt.hash(password, 12) }, select: { id: true } });
    await createSession(user.id);
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch { return NextResponse.json({ error: "Registrace momentálně není dostupná." }, { status: 500 }); }
}
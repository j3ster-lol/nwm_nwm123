import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { currentUser } from "@/lib/auth";
import { messageSchema } from "@/lib/validation";
type Ctx = { params: Promise<{ channelId: string }> };
export async function GET(_req: Request, ctx: Ctx) {
  const user = await currentUser(); if (!user) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  const { channelId } = await ctx.params;
  const channel = await db.channel.findFirst({ where: { id: channelId, server: { memberships: { some: { userId: user.id } } } }, select: { id: true } });
  if (!channel) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
  const messages = await db.message.findMany({ where: { channelId, deletedAt: null }, orderBy: { createdAt: "desc" }, take: 100, include: { author: { select: { id: true, username: true, avatarUrl: true } }, reactions: true } });
  return NextResponse.json({ messages: messages.reverse() });
}
export async function POST(req: Request, ctx: Ctx) {
  const user = await currentUser(); if (!user) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  const { channelId } = await ctx.params; const raw = await req.json();
  const parsed = messageSchema.safeParse({ ...raw, channelId });
  if (!parsed.success) return NextResponse.json({ error: "Zpráva musí mít 1–4000 znaků." }, { status: 400 });
  const membership = await db.membership.findFirst({ where: { userId: user.id, server: { channels: { some: { id: channelId } } } }, select: { id: true } });
  if (!membership) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  const message = await db.message.create({ data: { channelId, authorId: user.id, content: parsed.data.content, replyToId: parsed.data.replyToId }, include: { author: { select: { id: true, username: true, avatarUrl: true } }, reactions: true } });
  return NextResponse.json({ message }, { status: 201 });
}
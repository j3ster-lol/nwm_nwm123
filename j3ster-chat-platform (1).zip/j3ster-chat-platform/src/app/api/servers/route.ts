import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { currentUser } from "@/lib/auth";
import { z } from "zod";
const schema = z.object({ name: z.string().trim().min(2).max(80), description: z.string().max(300).optional() });
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  const servers = await db.server.findMany({ where: { memberships: { some: { userId: user.id } } }, include: { channels: { orderBy: { position: "asc" } } }, orderBy: { createdAt: "asc" } });
  return NextResponse.json({ servers });
}
export async function POST(req: Request) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Název musí mít 2–80 znaků." }, { status: 400 });
  try {
    const server = await db.$transaction(async (tx) => {
      const created = await tx.server.create({ data: { ...parsed.data, ownerId: user.id,
        memberships: { create: { userId: user.id, role: "OWNER" } } } });
      const category = await tx.category.create({ data: { name: "Textové kanály", serverId: created.id } });
      await tx.channel.create({ data: { name: "obecný-chat", serverId: created.id, categoryId: category.id } });
      return tx.server.findUniqueOrThrow({ where: { id: created.id }, include: { channels: true } });
    });
    return NextResponse.json({ server }, { status: 201 });
  } catch { return NextResponse.json({ error: "Server se nepodařilo vytvořit." }, { status: 500 }); }
}
import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "J3STER // Network", description: "A community platform for conversations, servers and friends." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="cs"><body>{children}</body></html>;
}
import Link from "next/link";
import { currentUser } from "@/lib/auth";
import { MessageCircle, ShieldCheck, Users, Zap, ArrowRight } from "lucide-react";
export default async function Home() {
  const user = await currentUser();
  return <main style={{minHeight:"100vh",background:"radial-gradient(ellipse at 50% -10%,#342657 0%,#17151f 35%,#101116 70%)"}}>
    <nav style={{height:78,display:"flex",alignItems:"center",justifyContent:"space-between",maxWidth:1180,margin:"auto",padding:"0 24px"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,fontWeight:900,letterSpacing:"-.04em"}}><span className="rail-logo" style={{width:40,height:40,borderRadius:13}}>J3</span> J3STER <span className="muted">// NETWORK</span></div>
      <div style={{display:"flex",gap:12}}>{user ? <Link className="btn" href="/app">Otevřít aplikaci <ArrowRight size={16} style={{display:"inline",verticalAlign:"middle"}}/></Link> : <><Link className="btn secondary" href="/login">Přihlásit se</Link><Link className="btn" href="/register">Začít zdarma</Link></>}</div>
    </nav>
    <section style={{maxWidth:1180,margin:"auto",padding:"95px 24px 72px",textAlign:"center"}}>
      <div className="pill" style={{display:"inline-block"}}>✦ KOMUNITA. KOMUNIKACE. TVOJE PRAVIDLA.</div>
      <h1 style={{fontSize:"clamp(42px,7vw,78px)",lineHeight:1.02,letterSpacing:"-.055em",maxWidth:900,margin:"28px auto 20px"}}>Všechno pro tvoji komunitu.<br/><span style={{color:"#b9a5ff"}}>Na jednom místě.</span></h1>
      <p className="muted" style={{fontSize:18,lineHeight:1.7,maxWidth:650,margin:"0 auto 30px"}}>Moderní prostor pro servery, zprávy a lidi, se kterými chceš být v kontaktu. Vytvoř si vlastní komunitu a nastav jí pravidla.</p>
      <div style={{display:"flex",justifyContent:"center",gap:12,flexWrap:"wrap"}}><Link className="btn" href={user?"/app":"/register"} style={{padding:"14px 20px"}}>Vytvořit účet <ArrowRight size={16} style={{display:"inline",verticalAlign:"middle"}}/></Link><Link className="btn secondary" href="/login" style={{padding:"14px 20px"}}>Už mám účet</Link></div>
      <div style={{maxWidth:850,margin:"70px auto 0",padding:10,background:"#1a1823",border:"1px solid #383047",borderRadius:22,boxShadow:"0 30px 100px #0008"}}>
        <div style={{background:"#111218",borderRadius:15,minHeight:300,display:"grid",gridTemplateColumns:"62px 180px 1fr",textAlign:"left",overflow:"hidden"}}>
          <div style={{background:"#0c0d11",padding:9,display:"grid",alignContent:"start",gap:10}}>{["J3","✦","N","G"].map((x,i)=><div key={i} className={i===0?"rail-logo":"server-icon"} style={{width:42,height:42,borderRadius:14}}>{x}</div>)}</div>
          <div style={{padding:18,borderRight:"1px solid #292b35"}}><b>Moje komunita</b><p className="eyebrow" style={{marginTop:26}}>TEXTOVÉ KANÁLY</p>{["# obecný-chat","# oznámení","# sdílení"].map(x=><div key={x} className="navitem">{x}</div>)}</div>
          <div style={{padding:22,display:"flex",flexDirection:"column",justifyContent:"space-between"}}><div><b># obecný-chat</b><p className="muted" style={{fontSize:13}}>Vítej ve své komunitě.</p><div className="panel" style={{padding:14,marginTop:30,maxWidth:330}}><b style={{fontSize:13}}>J3STER</b><p style={{fontSize:13,marginBottom:0}} className="muted">Tvoje komunita. Tvoje pravidla. ✨</p></div></div><div className="panel muted" style={{padding:12,fontSize:13}}>Napiš zprávu…</div></div>
        </div>
      </div>
    </section>
    <section style={{maxWidth:1080,margin:"0 auto",padding:"30px 24px 90px",display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:16}}>
      {[{icon:MessageCircle,title:"Komunikace",desc:"Textové kanály a historie zpráv pro tvoji komunitu."},{icon:Users,title:"Komunity",desc:"Vytvářej servery, spravuj členy a pozvánky."},{icon:ShieldCheck,title:"Bezpečnost",desc:"Role, moderace a serverově ověřovaná oprávnění."},{icon:Zap,title:"Rychlé rozhraní",desc:"Tmavý, responzivní design pro desktop i mobil."}].map(x=><div className="panel" key={x.title} style={{padding:22}}><x.icon color="#b9a5ff" size={24}/><h3>{x.title}</h3><p className="muted" style={{lineHeight:1.6,fontSize:14}}>{x.desc}</p></div>)}
    </section>
    <footer className="muted" style={{borderTop:"1px solid #282a34",padding:25,textAlign:"center",fontSize:12}}>J3STER // NETWORK · Community platform</footer>
  </main>;
}
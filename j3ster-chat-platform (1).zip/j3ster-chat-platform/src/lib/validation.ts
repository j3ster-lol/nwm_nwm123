import { z } from "zod";
export const registerSchema = z.object({
  email: z.email().max(254),
  username: z.string().trim().min(3).max(24).regex(/^[a-zA-Z0-9_]+$/),
  password: z.string().min(12).max(128)
});
export const messageSchema = z.object({
  channelId: z.string().min(1).max(64),
  content: z.string().trim().min(1).max(4000),
  replyToId: z.string().max(64).optional()
});
export function safeError(error: unknown) {
  if (error instanceof Error && ["UNAUTHORIZED", "FORBIDDEN"].includes(error.message)) return error.message;
  return "REQUEST_FAILED";
}

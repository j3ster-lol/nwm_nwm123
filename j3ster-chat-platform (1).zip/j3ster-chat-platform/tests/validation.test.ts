import { describe, expect, it } from "vitest";
import { registerSchema, messageSchema } from "../src/lib/validation";
describe("input validation", () => {
  it("requires a strong minimum password length", () => {
    expect(registerSchema.safeParse({ email:"a@example.com", username:"valid_user", password:"short" }).success).toBe(false);
    expect(registerSchema.safeParse({ email:"a@example.com", username:"valid_user", password:"long-enough-password" }).success).toBe(true);
  });
  it("rejects oversized messages", () => {
    expect(messageSchema.safeParse({ channelId:"c1", content:"" }).success).toBe(false);
    expect(messageSchema.safeParse({ channelId:"c1", content:"hello" }).success).toBe(true);
    expect(messageSchema.safeParse({ channelId:"c1", content:"x".repeat(4001) }).success).toBe(false);
  });
});